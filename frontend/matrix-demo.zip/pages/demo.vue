<script setup lang="ts">
const { user, token, login, logout, me } = useAuth()
const { get, post } = useApi()
const username = ref('employee')
const password = ref('employee123')
const step = ref<'login'|'dashboard'|'attempt'|'result'>('login')
const modules = ref<any[]>([])
const startPayload = ref<any | null>(null)
const answers = ref<Record<string, string[]>>({})
const result = ref<any | null>(null)

async function doLogin() {
  await login(username.value, password.value)
  modules.value = await get('/modules/')
  step.value = 'dashboard'
}

async function startAttempt(mod:any) {
  const sp = await post(`/modules/${mod.id}/start/`, {})
  startPayload.value = sp
  for (const q of sp.questions) answers.value[q.id] = []
  step.value = 'attempt'
}

async function submitAttempt() {
  const payload = { answers: Object.entries(answers.value).map(([question_id, choice_ids]) => ({ question_id, choice_ids })) }
  result.value = await post(`/attempts/${startPayload.value.attempt_id}/submit/`, payload)
  step.value = 'result'
}
</script>

<template>
  <div class="p-6 max-w-2xl mx-auto">
    <h1 class="text-2xl mb-4 font-bold">Matrix Demo</h1>
    <div v-if="step==='login'">
      <input v-model="username" class="border p-2 w-full mb-2" placeholder="Username"/>
      <input v-model="password" type="password" class="border p-2 w-full mb-2" placeholder="Password"/>
      <button @click="doLogin" class="bg-black text-white px-4 py-2 rounded">Login</button>
    </div>
    <div v-else-if="step==='dashboard'">
      <h2 class="font-semibold mb-2">Modules</h2>
      <ul><li v-for="m in modules" :key="m.id" class="border p-2 mb-2 flex justify-between">
        <div>{{ m.title }}</div><button @click="startAttempt(m)" class="bg-black text-white px-2 py-1 rounded">Start</button>
      </li></ul>
    </div>
    <div v-else-if="step==='attempt'">
      <div v-for="q in startPayload.questions" :key="q.id" class="border p-2 mb-2">
        <div>{{ q.text }}</div>
        <div v-for="c in q.choices" :key="c.id"><label><input type="checkbox" v-model="answers[q.id]" :value="c.id"/> {{ c.text }}</label></div>
      </div>
      <button @click="submitAttempt" class="bg-black text-white px-4 py-1 rounded">Submit</button>
    </div>
    <div v-else-if="step==='result'">
      <h2>Result: {{ result.percent }}%</h2>
    </div>
  </div>
</template>
