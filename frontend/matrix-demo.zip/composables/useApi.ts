export function useApi() {
  const config = useRuntimeConfig()
  const baseURL = config.public.apiBase || 'http://127.0.0.1:8000/api'
  const token = useState<string | null>('token', () => process.client ? localStorage.getItem('token') : null)

  const authHeaders = () => token.value ? { Authorization: `Bearer ${token.value}` } : {}

  async function get<T>(url: string) {
    return $fetch<T>(url, { baseURL, headers: authHeaders() })
  }

  async function post<T>(url: string, body?: any) {
    return $fetch<T>(url, { method: 'POST', baseURL, body, headers: { 'Content-Type': 'application/json', ...authHeaders() } })
  }

  return { token, baseURL, get, post }
}
