type TokenResp = { access: string; refresh: string }

export function useAuth() {
  const { token, post } = useApi()
  const user = useState<{ username: string; biz_role: string | null } | null>('user', () => null)
  const loading = useState<boolean>('authLoading', () => false)
  const error = useState<string | null>('authError', () => null)

  async function login(username: string, password: string) {
    loading.value = true
    try {
      const t = await post<TokenResp>('/auth/token/', { username, password })
      token.value = t.access
      if (process.client) localStorage.setItem('token', t.access)
      user.value = await me()
    } finally { loading.value = false }
  }

  async function me() {
    const me = await useApi().get<{ username: string; biz_role: string | null }>('/me/whoami/')
    user.value = me
    return me
  }

  function logout() {
    token.value = null
    user.value = null
    if (process.client) localStorage.removeItem('token')
  }

  return { token, user, loading, error, login, logout, me }
}
