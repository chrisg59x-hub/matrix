﻿<template><NuxtPage /></template>
