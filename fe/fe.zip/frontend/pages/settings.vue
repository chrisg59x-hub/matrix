<script setup>
</script>

<template>
  <div class="max-w-3xl mx-auto space-y-4">
    <header class="space-y-1">
      <h1 class="text-2xl font-bold">
        Settings
      </h1>
      <p class="text-sm text-gray-600">
        System-wide configuration. This is currently a placeholder – we can wire real options later
        (e.g. pass mark defaults, XP rules, or branding).
      </p>
    </header>

    <div class="p-4 bg-white rounded-xl shadow text-sm text-gray-700">
      <p>
        No configurable settings are exposed in the UI yet. Use this page as the future home for:
      </p>
      <ul class="list-disc list-inside mt-2 space-y-1">
        <li>Default module difficulty / pass mark presets</li>
        <li>XP rules for events (passes, streaks, sign-offs)</li>
        <li>Branding (logo, colours, organisation name)</li>
      </ul>
    </div>
  </div>
</template>
