﻿<script setup>
navigateTo('/dashboard')
</script>

