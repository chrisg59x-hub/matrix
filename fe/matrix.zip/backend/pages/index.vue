﻿<template><div style='padding:2rem'>Index is working ✅</div></template>
