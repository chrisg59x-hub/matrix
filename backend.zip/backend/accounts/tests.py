from django.test import TestCase


class SmokeTests(TestCase):
    def test_smoke(self):
        self.assertTrue(True)


# Create your tests here.
