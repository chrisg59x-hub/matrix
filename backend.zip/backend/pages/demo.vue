﻿<template>
  <div style='padding:2rem;font-family:sans-serif'>
    <h1>Demo route is working 🎉</h1>
  </div>
</template>
